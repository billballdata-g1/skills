---
name: wsl-vhdx-recovery
description: WSL VHDX compaction 中断后的完整修复流程
---

# WSL VHDX Compaction 中断修复指南

## 场景

使用 `diskpart` 的 `compact vdisk` 压缩 WSL2 的 `ext4.vhdx` 时，进程在 90% 左右被中断（被杀或超时），导致：

- VHDX 文件 footer 损坏 → WSL 无法挂载（`ERROR_SHARING_VIOLATION`）
- ext4 文件系统 metadata 不一致 → 部分文件报 `Bad message`
- 总损坏文件数可能上千，但**几乎全是可重建的缓存/依赖**

---

## 修复原理

| 问题 | 修复方式 |
|------|---------|
| VHDX footer 损坏 | 将有效的 header 复制到 footer 位置 |
| ext4 文件系统脏数据 | `fsck.ext4` 修复 inode 和块计数 |
| 文件系统空洞 | `fstrim` 标记空闲块，压缩前必须做 |
| 大量缓存/依赖损坏 | 通过包管理器重建（pip / npm / rustup / git fetch） |

---

## 完整修复流程

### 阶段 0：备份（最重要）

```powershell
# 在操作任何副本前，先备份原件
# 如果原件被锁定，使用 handle64 排查锁定进程
Copy-Item "C:\path\to\ext4.vhdx" "D:\backup\ext4_backup.vhdx" -Force
```

**原则**：所有写操作只在副本上进行，原件保留不动。

---

### 阶段 1：验证 VHDX 容器完整性

```powershell
# 安装新版 qemu-img（旧版 2.3.0 不支持 VHDX）
winget install SoftwareFreedomConservancy.QEMU

# 检查 VHDX 结构
& "C:\Program Files\qemu\qemu-img.exe" check -r all "E:\ext4_working.vhdx"
```

输出应为 `No errors were found on the image.`，说明 VHDX 容器本身完好。

---

### 阶段 2：修复 VHDX Footer

如果 VHDX footer 损坏（header 显示 `vhdxfile` 但 footer 是乱码或空）：

```powershell
# 将有效的 header 复制到 footer 位置
$vhdx = "E:\ext4_working.vhdx"
$stream = [System.IO.File]::Open($vhdx, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::Read)
$buffer = New-Object byte[] 4096
$stream.Read($buffer, 0, 4096) | Out-Null           # 读取 header（前 4KB）
$stream.Seek(-4096, [System.IO.SeekOrigin]::End) | Out-Null  # 跳到文件尾
$stream.Write($buffer, 0, 4096)                      # 写入 footer
$stream.Flush(); $stream.Close()

# 验证
$check = [System.IO.File]::OpenRead($vhdx)
$check.Seek(-4096, [System.IO.SeekOrigin]::End) | Out-Null
$verify = New-Object byte[] 8
$check.Read($verify, 0, 8) | Out-Null
$check.Close()
Write-Output "Footer: [$([System.Text.Encoding]::ASCII.GetString($verify))]"
# 输出应为: Footer: [vhdxfile]
```

---

### 阶段 3：创建恢复环境

如果不能启动 WSL 原始发行版，需要创建一个临时的 Alpine Linux 恢复环境：

```powershell
# 1. 下载 Alpine rootfs
$env:HTTP_PROXY="socks5://127.0.0.1:10808"  # 如有代理
Invoke-WebRequest -Uri "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86_64/alpine-minirootfs-3.20.3-x86_64.tar.gz" -OutFile "$env:TEMP\alpine.tar.gz"

# 2. 导入为 WSL 发行版
wsl --import Alpine-Recovery "E:\alpine\" "$env:TEMP\alpine.tar.gz" --version 2

# 3. 设置为默认启动
wsl --set-default Alpine-Recovery

# 4. 进入 Alpine
wsl
```

---

### 阶段 4：检查 ext4 文件系统

在 Alpine 恢复环境中挂载 VHDX 并运行 fsck：

```powershell
# 从 Windows 用 --bare 方式挂载 VHDX 为块设备
wsl --mount --vhd --bare "E:\ext4_working.vhdx"

# 在 Alpine 中找到对应的块设备
wsl -d Alpine-Recovery -- cat /proc/partitions
# 注意 1TB 的设备（1073741824 blocks），通常为 sdd 或 sde

# 安装 e2fsprogs 并运行 fsck
wsl -d Alpine-Recovery -- sh -c "
apk add e2fsprogs
fsck.ext4 -f -y /dev/sdd
"

# fsck 会修复:
# - Free inodes count wrong
# - Directories count wrong
# - blocks count mismatch
```

---

### 阶段 5：提取数据（可选）

如果 VHDX 无法修复或需要备份数据：

```powershell
# 方法 A: 直接从 Alpine 挂载并复制
wsl -d Alpine-Recovery -- sh -c "
mount /dev/sdd /mnt
cp -a /mnt/home/billv /mnt/e/billv_backup/
umount /mnt
"

# 方法 B: 转换为 qcow2 再操作（更安全）
& "C:\Program Files\qemu\qemu-img.exe" convert -f vhdx -O qcow2 -p "E:\ext4_working.vhdx" "E:\ext4_recovery.qcow2"

# 方法 C: 用 wsl --mount --vhd 挂载后从 Alpine 读取
wsl --mount --vhd "E:\ext4_working.vhdx"
# 挂载点在 /mnt/wsl/<Name>/
```

---

### 阶段 6：迁移 WSL 到其他盘（可选）

如果 C 盘空间不足，可以将 WSL 迁移到其他盘：

```powershell
# 1. 原件改名（防止 --unregister 自动删除）
Rename-Item "C:\Users\billv\AppData\Local\wsl\{GUID}\ext4.vhdx" "ext4.vhdx.bak"

# 2. 注销旧系统（释放 C 盘空间）
wsl --unregister Ubuntu-24.04

# 3. 在目标盘注册修复后的 VHDX
wsl --import-in-place Ubuntu-24.04 "E:\ext4_final.vhdx"

# 4. 设为默认
wsl --set-default Ubuntu-24.04
```

---

### 阶段 7：修复完成后收尾

```bash
# 在 Ubuntu 中执行
sudo fstrim -v /                        # 回收 VHDX 空洞空间
sudo apt clean                          # 清理 apt 缓存
sudo journalctl --vacuum-size=500M      # 清理日志
```

#### 重建损坏的环境

```bash
# Python venv 重建
cd /home/billv/workspace
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# ComfyUI venv
cd /home/billv/ComfyUI
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# npm 包
cd /home/billv/workspace
npm install

# Rust 工具链
rustup update

# Git 数据恢复（在各仓库目录）
git fetch --all

# Docker 镜像清理
docker system prune -a
```

---

### 阶段 8：重新 compact（正确做法）

修复完成并确认数据无误后，如果需要再次压缩 VHDX：

```powershell
# 1. WSL 内先做 fstrim 告知 VHDX 哪些块空闲
wsl -d Ubuntu-24.04 -- sudo fstrim -v /

# 2. 关机
wsl --shutdown

# 3. 压缩（等它跑完，不要中断！）
diskpart
select vdisk file="E:\ext4_final.vhdx"
compact vdisk
exit
```

**⚠️ 关键**：
- 压缩前务必先执行 `fstrim`
- 压缩过程中**绝对不要中断**
- 如果怕中断，可以在另找时间、系统空闲时做

---

## 工具清单

| 工具 | 用途 | 获取方式 |
|------|------|---------|
| `qemu-img` | VHDX 容器检查 / 格式转换 | `winget install SoftwareFreedomConservancy.QEMU` |
| `handle64` | 排查文件锁定进程 | `https://live.sysinternals.com/handle64.exe` |
| `e2fsprogs` | ext4 文件系统修复 | Alpine: `apk add e2fsprogs` |
| `wsl --mount --vhd` | 挂载 VHDX 为块设备 | WSL 内置 |
| `wsl --import-in-place` | 注册现有 VHDX 为发行版 | WSL 内置 |

---

## 预防措施

1. **压缩前必做**：
   ```bash
   sudo fstrim -v /
   ```

2. **启用稀疏 VHDX**（自动回收）：
   ```powershell
   wsl --manage Ubuntu-24.04 --set-sparse true --allow-unsafe
   ```

3. **把 WSL 迁到非系统盘**，避免 C 盘被撑爆

4. **定期清理**：
   ```bash
   sudo fstrim -v /
   docker system prune -a
   sudo journalctl --vacuum-size=500M
   ```

5. **备份策略**：
   - 重要代码推 git 远程
   - 模型文件单独备份
   - VHDX 定期用 `wsl --export` 导出

---

## 注意事项

| 问题 | 说明 |
|------|------|
| `wsl --import-in-place` + `--unregister` | **会删除 VHDX 文件**，注册前先备份 |
| `error while writing at byte 0` | qemu-img 写 raw 格式时有 bug，改用 qcow2 中转 |
| `ERROR_SHARING_VIOLATION` | VHDX footer 损坏或文件被锁定 |
| `E_UNEXPECTED` | ext4 文件系统脏，需运行 fsck |
| `WSL_E_USER_VHD_ALREADY_ATTACHED` | VHDX 已被 `wsl --mount` 挂载，先 unmount |
